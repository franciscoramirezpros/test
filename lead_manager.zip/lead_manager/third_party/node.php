<?php 
	defined('LM_REG_PROD_POINT') or define('LM_REG_PROD_POINT', 'https://envato.zonvoir.com/api/module/add');
	defined('LM_VAL_PROD_POINT') or define('LM_VAL_PROD_POINT', 'https://envato.zonvoir.com/api/module/check');
?>
<?php

defined('BASEPATH') or exit('No direct script access allowed');

return [ 
		'admin/lead_manager/sms_control/incoming_sms_status_webhook',
	 	'lead_manager/Sms_control/incoming_whatsapp_webhook',
	 	'lead_manager/Sms_control/incoming_whatsapp_status',
		'lead_manager/apis.*+'
	  ];